'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Search, ChevronDown, CheckCircle, ArrowRight, Server, ShieldCheck, Zap, Menu, X, Bell, LayoutDashboard } from 'lucide-react';
import emailjs from '@emailjs/browser';
import VideoGlobe from '../components/ThreeGlobe';


// --- PIERRES EFFECT 1: Magnetic Elements ---
const MagneticWrapper = ({ children, strength = 0.3, className = '' }) => {
  const ref = useRef(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e) => {
    if (!ref.current) return;
    const { left, top, width, height } = ref.current.getBoundingClientRect();
    const centerX = left + width / 2;
    const centerY = top + height / 2;
    const x = (e.clientX - centerX) * strength;
    const y = (e.clientY - centerY) * strength;
    setPosition({ x, y });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setPosition({ x: 0, y: 0 });
  };

  return (
    <div
      ref={ref}
      onMouseEnter={() => setIsHovered(true)}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`inline-block ${className}`}
    >
      <div
        style={{
          transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
          transition: isHovered ? 'none' : 'transform 0.7s cubic-bezier(0.25, 1, 0.5, 1)'
        }}
        className="w-full h-full"
      >
        {children}
      </div>
    </div>
  );
};

// --- PIERRES EFFECT 2: Masked Text Reveal ---
const MaskedReveal = ({ children, delay = 0 }) => {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className="overflow-hidden inline-block w-full py-1">
      <div
        className={`transition-transform duration-[1200ms] ease-[cubic-bezier(0.19,1,0.22,1)] ${
          isVisible ? 'translate-y-0' : 'translate-y-[110%]'
        }`}
        style={{ transitionDelay: `${delay}ms` }}
      >
        {children}
      </div>
    </div>
  );
};

// --- APPLE EFFECT: Fade & Float Up ---
const RevealOnScroll = ({ children, delay = 0, className = '' }) => {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.15 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-[cubic-bezier(0.25,0.46,0.45,0.94)] ${
        isVisible ? 'opacity-100 translate-y-0 blur-none' : 'opacity-0 translate-y-12 blur-[4px]'
      } ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
};

const SyndexusLanding = () => {
  const [activePhase, setActivePhase] = useState(0);
  
  // NAV MENU STATES
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobilePlatformOpen, setIsMobilePlatformOpen] = useState(false); 
  const [isDesktopPlatformOpen, setIsDesktopPlatformOpen] = useState(false); 
  
  const [isMobileToolsOpen, setIsMobileToolsOpen] = useState(false);
  const [isDesktopToolsOpen, setIsDesktopToolsOpen] = useState(false);
  
  // WAITLIST MODAL STATE
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  // --- REAL EMAILJS INTEGRATION ---
  const handleWaitlistSubmit = (e) => {
    e.preventDefault();
    
    const templateParams = {
      user_email: email, 
    };

    emailjs.send(
      'service_pekurd4',    // Replace with your EmailJS Service ID
      'template_viuxoin',   // Replace with your EmailJS Template ID
      templateParams,
      'hNhaShEYUFFyuLj3t'     // Replace with your EmailJS Public Key
    )
    .then((response) => {
      console.log('SUCCESS!', response.status, response.text);
      console.log(templateParams)
      setIsSubmitted(true);
      
      // Close modal after showing success message for 3 seconds
      setTimeout(() => {
        setIsModalOpen(false);
        setIsSubmitted(false);
        setEmail('');
      }, 3000);
    })
    .catch((err) => {
      console.error('FAILED...', err);
      alert("Email failed to send. Have you replaced the YOUR_SERVICE_ID and API keys in the code yet?");
    });
  };

  // SCROLL SPY LOGIC
  useEffect(() => {
    const handleScroll = () => {
      const phases = document.querySelectorAll('.scroll-phase');
      let current = activePhase;
      
      phases.forEach((phase, index) => {
        const rect = phase.getBoundingClientRect();
        if (rect.top <= window.innerHeight * 0.55 && rect.bottom >= window.innerHeight * 0.45) {
          current = index;
        }
      });
      
      if (current !== activePhase) {
        setActivePhase(current);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); 
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, [activePhase]);

  // ACTIVE THEORY 3D TILT
  const handleMouseMove = (e) => {
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -4; 
    const rotateY = ((x - centerX) / centerX) * 4;
    card.style.transform = `perspective(2000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.01, 1.01, 1.01)`;
  };

  const handleMouseLeave = (e) => {
    e.currentTarget.style.transform = `perspective(2000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
  };

  return (
    <div className="min-h-screen font-sans bg-[#FFFFFF] text-[#0F172A] overflow-x-hidden relative">
      

      {/* --- EARLY ACCESS MODAL --- */}
      <div className={`fixed inset-0 z-[100] flex items-center justify-center transition-all duration-500 ${isModalOpen ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'}`}>
        <div 
          className="absolute inset-0 bg-[#0F172A]/30 backdrop-blur-md" 
          onClick={() => setIsModalOpen(false)}
        ></div>
        
        <div className={`relative bg-white rounded-3xl p-8 shadow-2xl w-full max-w-md mx-4 transition-transform duration-500 ease-[cubic-bezier(0.25,0.46,0.45,0.94)] ${isModalOpen ? 'scale-100 translate-y-0' : 'scale-95 translate-y-8'}`}>
          <button 
            onClick={() => setIsModalOpen(false)} 
            className="absolute top-4 right-4 p-2 text-gray-400 hover:text-[#0F172A] transition-colors rounded-full hover:bg-gray-50"
          >
            <X size={20} />
          </button>
          
          {!isSubmitted ? (
            <div className="text-center pt-4">
              <h3 className="text-3xl font-bold text-[#0F172A] mb-3 tracking-tight">Request Access</h3>
              <p className="text-gray-500 text-sm mb-8 px-4 leading-relaxed">
                Join the waitlist for Syndexus OS v1.0. We are currently onboarding select enterprise partners.
              </p>
              <form onSubmit={handleWaitlistSubmit} className="space-y-4">
                <div>
                  <input 
                    type="email" 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@company.com" 
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:border-[#0D9488] focus:ring-4 focus:ring-[#0D9488]/10 transition-all text-[#0F172A] font-medium placeholder-gray-400"
                  />
                </div>
                <button type="submit" className="w-full bg-[#0F172A] text-white px-6 py-4 rounded-2xl font-bold hover:bg-[#0D9488] hover:shadow-lg hover:shadow-teal-900/20 active:scale-95 transition-all duration-300">
                  Join Waitlist
                </button>
              </form>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-6 text-[#10B981]">
                <CheckCircle size={40} />
              </div>
              <h3 className="text-3xl font-bold text-[#0F172A] mb-3 tracking-tight">You're on the list!</h3>
              <p className="text-gray-500 font-medium">Keep an eye on <span className="text-[#0F172A]">{email}</span> for your invitation.</p>
            </div>
          )}
        </div>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes gradient-x {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        .animate-gradient-x {
          animation: gradient-x 6s ease-in-out infinite;
          background-size: 200% 200%;
        }
        .tilt-card {
          transition: transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }
        .tilt-card:hover {
          transition: transform 0.1s ease-out;
          z-index: 50;
        }
      `}} />

      {/* --- RESPONSIVE NAVIGATION BAR --- */}
      <nav className="fixed top-0 w-full bg-white/90 backdrop-blur-xl saturate-150 z-50 border-b border-gray-100 shadow-sm transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 md:h-20 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2 hover:opacity-80 transition z-50">
            <span className="text-xl md:text-2xl font-extrabold text-[#0F172A] tracking-tight">
              SYNDEXUS
            </span>
          </a>
          
          <div className="hidden lg:flex items-center gap-8 text-sm font-medium text-gray-600">
            
            {/* DESKTOP PLATFORM DROPDOWN */}
            <div className="relative group">
              <MagneticWrapper strength={0.2}>
                <div 
                  onClick={() => setIsDesktopPlatformOpen(!isDesktopPlatformOpen)}
                  className="flex items-center gap-1 cursor-pointer hover:text-[#0D9488] transition-colors py-6 px-1"
                >
                  Platform <ChevronDown size={14} className={`transition-transform duration-300 group-hover:rotate-180 ${isDesktopPlatformOpen ? 'rotate-180' : ''}`} />
                </div>
              </MagneticWrapper>
              
              <div className={`absolute top-[90%] left-1/2 -translate-x-1/2 w-64 bg-white border border-gray-100 rounded-2xl shadow-xl shadow-gray-200/50 overflow-hidden transition-all duration-300 origin-top transform group-hover:opacity-100 group-hover:scale-100 group-hover:visible ${isDesktopPlatformOpen ? 'opacity-100 scale-100 visible' : 'opacity-0 scale-95 invisible'}`}>
                <div className="flex flex-col p-2">
                  <a href="/logistics" className="p-3 hover:bg-orange-50 rounded-xl transition-colors group/item">
                    <div className="flex items-center gap-3 mb-1">
                      <div className="w-2 h-2 rounded-full bg-[#F59E0B]"></div>
                      <span className="font-bold text-[#0F172A] group-hover/item:text-[#F59E0B] transition-colors">Logistics</span>
                    </div>
                    <p className="text-xs text-gray-500 pl-5">Smart routing & tracking</p>
                  </a>
                  
                  <a href="/trade" className="p-3 hover:bg-cyan-50 rounded-xl transition-colors group/item">
                    <div className="flex items-center gap-3 mb-1">
                      <div className="w-2 h-2 rounded-full bg-[#06B6D4]"></div>
                      <span className="font-bold text-[#0F172A] group-hover/item:text-[#06B6D4] transition-colors">Customs & Trade</span>
                    </div>
                    <p className="text-xs text-gray-500 pl-5">AI-powered ICEGATE filing</p>
                  </a>
                  
                  <a href="/pay" className="p-3 hover:bg-emerald-50 rounded-xl transition-colors group/item">
                    <div className="flex items-center gap-3 mb-1">
                      <div className="w-2 h-2 rounded-full bg-[#10B981]"></div>
                      <span className="font-bold text-[#0F172A] group-hover/item:text-[#10B981] transition-colors">Pay & Escrow</span>
                    </div>
                    <p className="text-xs text-gray-500 pl-5">Secure global settlements</p>
                  </a>
                </div>
              </div>
            </div>

            {/* DESKTOP TOOLS DROPDOWN */}
            <div className="relative group">
              <MagneticWrapper strength={0.2}>
                <div 
                  onClick={() => setIsDesktopToolsOpen(!isDesktopToolsOpen)}
                  className="flex items-center gap-1 cursor-pointer hover:text-[#0D9488] transition-colors py-6 px-1"
                >
                  Tools <ChevronDown size={14} className={`transition-transform duration-300 group-hover:rotate-180 ${isDesktopToolsOpen ? 'rotate-180' : ''}`} />
                </div>
              </MagneticWrapper>
              
              <div className={`absolute top-[90%] left-1/2 -translate-x-1/2 w-56 bg-white border border-gray-100 rounded-2xl shadow-xl shadow-gray-200/50 overflow-hidden transition-all duration-300 origin-top transform group-hover:opacity-100 group-hover:scale-100 group-hover:visible ${isDesktopToolsOpen ? 'opacity-100 scale-100 visible' : 'opacity-0 scale-95 invisible'}`}>
                <div className="flex flex-col p-2">
                  <a href="#" className="p-3 hover:bg-teal-50 rounded-xl transition-colors group/item">
                    <span className="font-bold text-[#0F172A] group-hover/item:text-[#0D9488] transition-colors">HS Code Finder</span>
                    <p className="text-xs text-gray-500 mt-1">Instant tariff classification</p>
                  </a>
                  
                  <a href="#" className="p-3 hover:bg-teal-50 rounded-xl transition-colors group/item">
                    <span className="font-bold text-[#0F172A] group-hover/item:text-[#0D9488] transition-colors">Duty Calculator</span>
                    <p className="text-xs text-gray-500 mt-1">Estimate landed costs</p>
                  </a>
                </div>
              </div>
            </div>

            <MagneticWrapper strength={0.2}>
              <a href="#" className="hover:text-[#0D9488] transition-colors py-6 px-1">Company</a>
            </MagneticWrapper>
          </div>
          
          <div className="flex items-center gap-4 sm:gap-6 z-50">
            {/* Search Bar COMPLETELY REMOVED from here */}
            
            <MagneticWrapper strength={0.4}>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="bg-[#0F172A] text-white px-4 py-2 md:px-6 md:py-2.5 rounded-full font-bold text-xs md:text-sm transition-all shadow-lg hover:shadow-xl hover:bg-[#0D9488]"
              >
                Get Started
              </button>
            </MagneticWrapper>

            <button 
              className="lg:hidden text-[#0F172A] p-1"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* MOBILE MENU */}
        <div className={`lg:hidden fixed inset-0 top-16 bg-white/95 backdrop-blur-3xl transition-all duration-300 ease-in-out overflow-y-auto ${isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'}`}>
          <div className="flex flex-col px-6 pt-10 pb-20 space-y-6 text-xl font-bold text-[#0F172A]">
            
            {/* MOBILE PLATFORM ACCORDION */}
            <div>
              <button 
                onClick={() => setIsMobilePlatformOpen(!isMobilePlatformOpen)}
                className="flex w-full justify-between items-center border-b border-gray-100 pb-4"
              >
                Platform <ChevronDown size={20} className={`text-gray-400 transition-transform duration-300 ${isMobilePlatformOpen ? 'rotate-180' : ''}`} />
              </button>
              
              <div className={`flex flex-col gap-2 overflow-hidden transition-all duration-300 ${isMobilePlatformOpen ? 'max-h-64 opacity-100 mt-4' : 'max-h-0 opacity-0'}`}>
                <a href="/logistics" className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <div className="w-2 h-2 rounded-full bg-[#F59E0B]"></div>
                  <span className="text-lg">Logistics</span>
                </a>
                <a href="/trade" className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <div className="w-2 h-2 rounded-full bg-[#06B6D4]"></div>
                  <span className="text-lg">Customs & Trade</span>
                </a>
                <a href="/pay" className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <div className="w-2 h-2 rounded-full bg-[#10B981]"></div>
                  <span className="text-lg">Pay & Escrow</span>
                </a>
              </div>
            </div>

            {/* MOBILE TOOLS ACCORDION */}
            <div>
              <button 
                onClick={() => setIsMobileToolsOpen(!isMobileToolsOpen)}
                className="flex w-full justify-between items-center border-b border-gray-100 pb-4"
              >
                Tools <ChevronDown size={20} className={`text-gray-400 transition-transform duration-300 ${isMobileToolsOpen ? 'rotate-180' : ''}`} />
              </button>
              
              <div className={`flex flex-col gap-2 overflow-hidden transition-all duration-300 ${isMobileToolsOpen ? 'max-h-64 opacity-100 mt-4' : 'max-h-0 opacity-0'}`}>
                <a href="#" className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <span className="text-lg">HS Code Finder</span>
                </a>
                <a href="#" className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <span className="text-lg">Duty Calculator</span>
                </a>
              </div>
            </div>

            <a href="#" className="border-b border-gray-100 pb-4">Company</a>
            
            {/* Search Bar COMPLETELY REMOVED from Mobile Nav Here */}
          </div>
        </div>
      </nav>

      {/* --- HERO SECTION --- */}
      <header className="relative flex flex-col items-center justify-center text-center px-4 pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_center,rgba(6,182,212,0.05),transparent_50%)] pointer-events-none"></div>

        <div className="relative z-10 flex flex-col items-center w-full">
          
          <RevealOnScroll delay={100}>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gray-50 border border-gray-200 text-gray-600 text-xs md:text-sm font-medium mb-6 md:mb-8">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#06B6D4] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#06B6D4]"></span>
              </span>
              Syndexus OS v1.0 is Live
            </div>
          </RevealOnScroll>

          <h1 className="text-5xl sm:text-6xl md:text-8xl font-bold text-[#0F172A] max-w-5xl tracking-tighter leading-[1.1] md:leading-[1.05] mb-6 flex flex-col items-center z-10">
            <MaskedReveal delay={100}>
              The Operating System
            </MaskedReveal>
            <MaskedReveal delay={250}>
              for <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#0F172A] via-[#06B6D4] to-[#0D9488] animate-gradient-x pb-2">Global Trade.</span>
            </MaskedReveal>
          </h1>
          
          <RevealOnScroll delay={600}>
            <p className="text-lg md:text-2xl text-gray-500 max-w-3xl mb-10 md:mb-12 leading-relaxed font-medium px-2">
              From factory floor to final settlement automated. <br className="hidden md:block" />
              The integrated OS for logistics, finance, and compliance.
            </p>
          </RevealOnScroll>
          
          <RevealOnScroll delay={800} className="w-full z-10">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8 mb-8 w-full px-4 sm:px-0">
              <MagneticWrapper strength={0.4} className="w-full sm:w-auto">
                <button 
                  onClick={() => setIsModalOpen(true)}
                  className="w-full sm:w-auto bg-[#0D9488] text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-[#0F172A] transition-colors duration-300 shadow-xl shadow-teal-900/10"
                >
                  Start Shipping
                </button>
              </MagneticWrapper>
              
              <MagneticWrapper strength={0.2}>
                <a href="#" className="group text-gray-600 font-medium hover:text-[#0F172A] transition-colors flex items-center justify-center gap-2 text-lg py-2">
                  View Interactive Demo 
                  <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </a>
              </MagneticWrapper>
            </div>
          </RevealOnScroll>
          
          <RevealOnScroll delay={1000} className="mb-20">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 text-xs md:text-sm font-medium text-gray-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="text-teal-500 w-4 h-4" /> 
                <span>Powered by Standard Chartered Escrow</span>
              </div>
              <span className="hidden sm:inline">|</span>
              <span>Licensed MTO</span>
            </div>
          </RevealOnScroll>

          {/* --- THE FLOATING UI DASHBOARD MOCKUP --- */}
          <RevealOnScroll delay={1200} className="w-full px-4 md:px-8">
            <div className="w-full max-w-[1000px] mx-auto perspective-[2000px]">
              <div 
                onMouseMove={handleMouseMove}
                onMouseLeave={handleMouseLeave}
                className="tilt-card relative w-full aspect-video md:h-[600px] bg-white border border-gray-200 rounded-t-[2rem] rounded-b-2xl shadow-[0_30px_60px_-15px_rgba(15,23,42,0.15)] overflow-hidden flex flex-col z-20"
              >
                <div className="h-12 border-b border-gray-100 flex items-center px-4 md:px-6 gap-4 bg-gray-50/50 backdrop-blur-md shrink-0">
                  <div className="flex gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-400"></div>
                    <div className="w-3 h-3 rounded-full bg-amber-400"></div>
                    <div className="w-3 h-3 rounded-full bg-green-400"></div>
                  </div>
                  <div className="hidden md:flex flex-1 justify-center">
                    {/* Note: This search bar is IN THE MOCKUP APP Dashboard UI, not the actual Website Nav */}
                    <div className="bg-white border border-gray-200 text-xs text-gray-400 px-32 py-1.5 rounded-md flex items-center gap-2 shadow-sm">
                      <Search size={14} /> Search Shipments, BL Numbers, or Invoices...
                    </div>
                  </div>
                  <div className="flex gap-4 text-gray-400 ml-auto md:ml-0">
                    <Bell size={16} />
                    <div className="w-5 h-5 rounded-full bg-teal-100 border border-teal-200"></div>
                  </div>
                </div>

                <div className="flex flex-1 overflow-hidden bg-[#FAFAFA]">
                  <div className="hidden md:flex flex-col w-64 border-r border-gray-100 bg-white p-6 gap-6 shrink-0">
                    <div className="flex items-center gap-3 text-[#0F172A] font-bold">
                      <LayoutDashboard size={20} className="text-[#0D9488]" /> Dashboard
                    </div>
                    <div className="space-y-4 mt-4">
                      <div className="h-8 w-full bg-teal-50 text-teal-700 rounded-md flex items-center px-3 text-sm font-medium border border-teal-100"> Active Shipments </div>
                      <div className="h-8 w-5/6 bg-white text-gray-500 rounded-md flex items-center px-3 text-sm font-medium hover:bg-gray-50"> Escrow Vault </div>
                      <div className="h-8 w-4/6 bg-white text-gray-500 rounded-md flex items-center px-3 text-sm font-medium hover:bg-gray-50"> Customs Docs </div>
                    </div>
                  </div>

                  <div className="flex-1 p-4 md:p-8 flex flex-col gap-4 md:gap-6 overflow-hidden">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6 shrink-0">
                      
                      <div className="h-20 md:h-24 bg-white border border-gray-100 rounded-xl shadow-sm p-4 flex flex-col justify-between relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-1 h-full bg-[#F59E0B]"></div>
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">In Transit</span>
                          <div className="w-6 h-6 rounded bg-orange-50 flex items-center justify-center"><CheckCircle size={12} className="text-[#F59E0B]" /></div>
                        </div>
                        <div className="text-2xl font-black text-[#0F172A]">24 <span className="text-sm font-medium text-gray-400 ml-1">TEUs</span></div>
                      </div>

                      <div className="h-20 md:h-24 bg-white border border-gray-100 rounded-xl shadow-sm p-4 flex flex-col justify-between relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-1 h-full bg-[#06B6D4]"></div>
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Pending Clearances</span>
                          <div className="w-6 h-6 rounded bg-cyan-50 flex items-center justify-center"><ShieldCheck size={12} className="text-[#06B6D4]" /></div>
                        </div>
                        <div className="text-2xl font-black text-[#0F172A]">3 <span className="text-sm font-medium text-gray-400 ml-1">Bills</span></div>
                      </div>

                      <div className="h-20 md:h-24 bg-white border border-gray-100 rounded-xl shadow-sm p-4 flex flex-col justify-between relative overflow-hidden hidden sm:flex">
                        <div className="absolute top-0 left-0 w-1 h-full bg-[#10B981]"></div>
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Escrow Balance</span>
                          <div className="w-6 h-6 rounded bg-emerald-50 flex items-center justify-center"><Server size={12} className="text-[#10B981]" /></div>
                        </div>
                        <div className="text-2xl font-black text-[#0F172A]">$1.4M <span className="text-sm font-medium text-emerald-500 ml-1">+12%</span></div>
                      </div>

                    </div>

                    <div className="flex-1 bg-white border border-gray-100 rounded-xl shadow-sm relative overflow-hidden flex items-center justify-center group">
                      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.05),transparent_70%)] z-0"></div>
                      <div className="w-full max-w-[400px] md:max-w-[500px] opacity-80 group-hover:opacity-100 transition-opacity duration-700 z-10">
                         <VideoGlobe activePhase={0} />
                      </div>
                      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1.5 rounded border border-gray-100 shadow-sm text-xs font-bold text-gray-500 z-20">
                        Live Fleet Tracking
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </RevealOnScroll>
        </div>
      </header>

      {/* --- THE CORE EXPERIENCE: STICKY SCROLL --- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12 flex flex-col md:flex-row items-start relative mt-12 md:mt-24">
        <div className="w-full md:w-1/2 md:pr-16 pb-12 md:pb-16">
          
          <div className="scroll-phase min-h-[50vh] md:min-h-[90vh] flex flex-col justify-center perspective-[2000px] mb-12 md:mb-0">
            <div 
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              className={`tilt-card p-6 md:p-10 rounded-3xl border border-gray-100 bg-white/80 backdrop-blur-sm transition-all origin-left ${
              activePhase === 0 ? 'opacity-100 scale-100 blur-none shadow-xl shadow-gray-200/50' : 'opacity-40 md:opacity-20 scale-100 md:scale-95 blur-none md:blur-[8px]'
            }`}>
              <h2 className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tighter text-[#0F172A] mb-4 md:mb-6">Move Goods.</h2>
              <p className="text-lg md:text-2xl text-gray-500 leading-relaxed mb-6 md:mb-8 font-medium">
                Smart Logistics, Zero Idle Time. Our routing engine predicts congestion and optimizes pickup schedules.
              </p>
              <div className="flex items-center gap-2 md:gap-3 text-[#F59E0B] font-bold text-base md:text-lg">
                <CheckCircle size={20} className="md:w-6 md:h-6" /> Reduce transit delays by 40%.
              </div>
            </div>
          </div>

          <div className="scroll-phase min-h-[50vh] md:min-h-[90vh] flex flex-col justify-center perspective-[2000px] mb-12 md:mb-0">
            <div 
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              className={`tilt-card p-6 md:p-10 rounded-3xl border border-gray-100 bg-white/80 backdrop-blur-sm transition-all origin-left ${
              activePhase === 1 ? 'opacity-100 scale-100 blur-none shadow-xl shadow-cyan-900/10' : 'opacity-40 md:opacity-20 scale-100 md:scale-95 blur-none md:blur-[8px]'
            }`}>
              <h2 className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tighter text-[#0F172A] mb-4 md:mb-6">Clear Customs.</h2>
              <p className="text-lg md:text-2xl text-gray-500 leading-relaxed mb-6 md:mb-8 font-medium">
                AI-powered documentation. Generate ICEGATE compliant invoices and shipping bills instantly.
              </p>
              <div className="flex items-center gap-2 md:gap-3 text-[#06B6D4] font-bold text-base md:text-lg">
                <CheckCircle size={20} className="md:w-6 md:h-6" /> Zero re-typing and errors.
              </div>
            </div>
          </div>

          <div className="scroll-phase min-h-[50vh] md:min-h-[90vh] flex flex-col justify-center perspective-[2000px]">
            <div 
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              className={`tilt-card p-6 md:p-10 rounded-3xl border border-gray-100 bg-white/80 backdrop-blur-sm transition-all origin-left ${
              activePhase === 2 ? 'opacity-100 scale-100 blur-none shadow-xl shadow-emerald-900/10' : 'opacity-40 md:opacity-20 scale-100 md:scale-95 blur-none md:blur-[8px]'
            }`}>
              <h2 className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tighter text-[#0F172A] mb-4 md:mb-6">Get Paid.</h2>
              <p className="text-lg md:text-2xl text-gray-500 leading-relaxed mb-6 md:mb-8 font-medium">
                Embed trust in every deal. Buyer pays into Escrow; funds released only when goods ship.
              </p>
              <div className="flex items-center gap-2 md:gap-3 text-[#10B981] font-bold text-base md:text-lg">
                <CheckCircle size={20} className="md:w-6 md:h-6" /> Get paid 5x faster.
              </div>
            </div>
          </div>

        </div>

        <div className="hidden md:flex w-1/2 sticky top-24 h-[calc(100vh-6rem)] items-center justify-center">
          <div className="absolute inset-10 bg-[radial-gradient(circle_at_center,rgba(0,0,0,0.03),transparent_70%)] rounded-[3rem] blur-2xl"></div>
          <div className="w-full h-full bg-[#FAFAFA] rounded-[3rem] border border-gray-100 flex items-center justify-center relative overflow-hidden shadow-2xl z-10 transition-colors duration-1000">
            <VideoGlobe activePhase={activePhase} />
          </div>
        </div>
      </section>

      {/* --- THE OS DIFFERENCE (Bridging the gap) --- */}
      <section className="py-24 md:py-32 bg-[#F8FAFC] border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
          
          <RevealOnScroll>
            <div className="text-center max-w-4xl mx-auto mb-16 md:mb-24">
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#0F172A] tracking-tighter mb-6">
                Replace 10 fragmented tools with 1 Operating System.
              </h2>
              <p className="text-lg md:text-xl text-gray-500 font-medium">
                We didn't just build another dashboard. We built an underlying infrastructure that connects your bank, your freight forwarder, and customs into one seamless workflow.
              </p>
            </div>
          </RevealOnScroll>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
             <RevealOnScroll delay={100} className="w-full">
               <div className="bg-white border border-gray-200 rounded-[2rem] p-8 md:p-12 shadow-sm h-full opacity-60 hover:opacity-100 transition-opacity duration-300">
                 <div className="flex items-center gap-3 mb-8 text-gray-400">
                   <X size={28} className="text-red-400" />
                   <h3 className="text-2xl font-bold tracking-tight text-[#0F172A]">The Old Way</h3>
                 </div>
                 <ul className="space-y-5 text-gray-500 font-medium text-lg">
                   <li className="flex gap-4"><span className="text-red-400 mt-1">→</span> Endless email threads with freight forwarders.</li>
                   <li className="flex gap-4"><span className="text-red-400 mt-1">→</span> Manual data entry for customs documentation.</li>
                   <li className="flex gap-4"><span className="text-red-400 mt-1">→</span> Opaque banking portals and high FX fees.</li>
                   <li className="flex gap-4"><span className="text-red-400 mt-1">→</span> Total blind spots in container tracking.</li>
                 </ul>
               </div>
             </RevealOnScroll>

             <RevealOnScroll delay={300} className="w-full">
               <div className="bg-white border border-teal-100 rounded-[2rem] p-8 md:p-12 shadow-xl shadow-teal-900/5 h-full relative overflow-hidden">
                 <div className="absolute top-0 right-0 w-48 h-48 bg-teal-50 rounded-bl-full -z-10 opacity-50"></div>
                 <div className="flex items-center gap-3 mb-8 text-[#0F172A] relative z-10">
                   <CheckCircle size={28} className="text-[#0D9488]" />
                   <h3 className="text-2xl font-bold tracking-tight">The Syndexus OS</h3>
                 </div>
                 <ul className="space-y-5 text-[#0F172A] font-bold text-lg relative z-10">
                   <li className="flex gap-4"><span className="text-[#0D9488] mt-1">→</span> Live GPS container tracking on a unified map.</li>
                   <li className="flex gap-4"><span className="text-[#0D9488] mt-1">→</span> AI-generated ICEGATE compliant documents.</li>
                   <li className="flex gap-4"><span className="text-[#0D9488] mt-1">→</span> Automated smart-escrow payouts upon delivery.</li>
                   <li className="flex gap-4"><span className="text-[#0D9488] mt-1">→</span> A single dashboard for all global trade data.</li>
                 </ul>
               </div>
             </RevealOnScroll>
          </div>

        </div>
      </section>

      {/* --- THE UNIFIED ARCHITECTURE --- */}
      <section className="py-20 md:py-32 bg-white relative overflow-hidden border-t border-gray-100">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800A_1px,transparent_1px),linear-gradient(to_bottom,#8080800A_1px,transparent_1px)] bg-[size:40px_40px]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
          
          <RevealOnScroll>
            <div className="text-center max-w-3xl mx-auto mb-16 md:mb-20">
              <h2 className="text-4xl md:text-6xl font-bold text-[#0F172A] tracking-tight mb-4 md:mb-6">A Single Source of Truth.</h2>
              <p className="text-lg md:text-xl text-gray-500 font-medium">
                Stop jumping between tabs. We unified the entire stack.
              </p>
            </div>
          </RevealOnScroll>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            <RevealOnScroll delay={100}>
              <div className="p-8 rounded-[2rem] bg-gray-50 border border-gray-200 hover:shadow-xl hover:border-teal-200 transition-all duration-300 h-full">
                <Server className="text-[#0D9488] w-8 h-8 md:w-10 md:h-10 mb-6" />
                <h3 className="text-xl md:text-2xl font-bold text-[#0F172A] mb-3">Real-time APIs</h3>
                <p className="text-gray-500 leading-relaxed font-medium">
                  Direct pipeline into your ERP. Push POs directly to our system and watch as logistics and escrow execute automatically.
                </p>
              </div>
            </RevealOnScroll>

            <RevealOnScroll delay={200}>
              <div className="p-8 rounded-[2rem] bg-gray-50 border border-gray-200 hover:shadow-xl hover:border-emerald-200 transition-all duration-300 h-full">
                <ShieldCheck className="text-[#10B981] w-8 h-8 md:w-10 md:h-10 mb-6" />
                <h3 className="text-xl md:text-2xl font-bold text-[#0F172A] mb-3">Immutable Ledger</h3>
                <p className="text-gray-500 leading-relaxed font-medium">
                  Every Bill of Lading, Invoice, and Payment is cryptographically verified and stored, eliminating document fraud entirely.
                </p>
              </div>
            </RevealOnScroll>

            <RevealOnScroll delay={300}>
              <div className="p-8 rounded-[2rem] bg-gray-50 border border-gray-200 hover:shadow-xl hover:border-cyan-200 transition-all duration-300 h-full">
                <Zap className="text-[#06B6D4] w-8 h-8 md:w-10 md:h-10 mb-6" />
                <h3 className="text-xl md:text-2xl font-bold text-[#0F172A] mb-3">Smart Workflows</h3>
                <p className="text-gray-500 leading-relaxed font-medium">
                  Condition-based execution. "If ICEGATE approves Shipping Bill AND Container passes gate, release 50% funds."
                </p>
              </div>
            </RevealOnScroll>
          </div>

        </div>
      </section>

      {/* --- SOCIAL PROOF --- */}
      <section className="py-16 md:py-24 bg-[#F8FAFC] border-t border-gray-200">
        <RevealOnScroll>
          <h3 className="text-center text-gray-400 font-bold tracking-widest uppercase text-xs md:text-sm mb-8 md:mb-12">
            Seamlessly Connected With
          </h3>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-24 opacity-60 mix-blend-multiply grayscale hover:grayscale-0 transition-all duration-700 px-4">
            <div className="text-xl sm:text-2xl md:text-3xl font-black text-[#0F172A] cursor-default transition-transform hover:scale-110">ICEGATE</div>
            <div className="text-xl sm:text-2xl md:text-3xl font-black text-[#0F172A] cursor-default transition-transform hover:scale-110">MAERSK</div>
            <div className="text-xl sm:text-2xl md:text-3xl font-black text-[#0F172A] cursor-default transition-transform hover:scale-110">HDFC BANK</div>
            <div className="text-xl sm:text-2xl md:text-3xl font-black text-[#0F172A] cursor-default transition-transform hover:scale-110">VAHAN</div>
          </div>
        </RevealOnScroll>
      </section>

      {/* --- FINAL CTA BANNER --- */}
      <section className="py-24 md:py-32 bg-[#0F172A] text-white relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] md:w-[800px] h-[400px] md:h-[800px] bg-[#06B6D4] opacity-20 md:opacity-10 blur-[60px] md:blur-[100px] rounded-full pointer-events-none"></div>
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10 text-center">
          <RevealOnScroll>
            <h2 className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tighter mb-6 md:mb-8">
              Ready to upgrade your supply chain?
            </h2>
            <p className="text-lg md:text-xl text-gray-400 font-medium mb-10 md:mb-12 max-w-2xl mx-auto">
              Join the waitlist for early access. Experience the future of logistics, trade compliance, and finance in one dashboard.
            </p>
            
            <MagneticWrapper strength={0.4}>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="w-full sm:w-auto bg-[#0D9488] text-white px-8 md:px-10 py-4 md:py-5 rounded-full font-bold text-lg md:text-xl hover:scale-105 active:scale-95 transition-all duration-300 shadow-2xl shadow-teal-900/50 flex items-center justify-center gap-3 mx-auto group"
              >
                Request Early Access
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </button>
            </MagneticWrapper>
          </RevealOnScroll>
        </div>
      </section>

      {/* --- FOOTER --- */}
      <footer className="bg-white py-16 md:py-20">
        <RevealOnScroll>
          <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-10 md:gap-12 mb-12 md:mb-16">
            <div className="col-span-1 sm:col-span-2 md:col-span-1">
              <div className="text-2xl font-extrabold text-[#0F172A] tracking-tight mb-4">SYNDEXUS</div>
              <p className="text-gray-500 font-medium leading-relaxed">Integrated Trade.<br/>Automated Trust.</p>
            </div>
            <div>
              <h4 className="font-bold text-[#0F172A] mb-4 md:mb-6 tracking-tight">Platform</h4>
              <ul className="space-y-3 text-gray-500 font-medium">
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">Logistics</a></li>
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">Escrow</a></li>
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">Customs</a></li>
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">Pricing</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[#0F172A] mb-4 md:mb-6 tracking-tight">Resources</h4>
              <ul className="space-y-3 text-gray-500 font-medium">
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">HS Code Finder</a></li>
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">Duty Calculator</a></li>
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">Port Data</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[#0F172A] mb-4 md:mb-6 tracking-tight">Legal</h4>
              <ul className="space-y-3 text-gray-500 font-medium">
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">Terms of Trade</a></li>
                <li><a href="#" className="hover:text-[#0D9488] transition-colors">Escrow Agreement</a></li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto px-6 pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center text-xs md:text-sm text-gray-400 font-medium text-center md:text-left">
            <p>&copy; 2026 Syndexus Technologies Pvt Ltd.</p>
            <p className="mt-4 md:mt-0">Made in India for the World.</p>
          </div>
        </RevealOnScroll>
      </footer>
    </div>
  );
};

export default SyndexusLanding;